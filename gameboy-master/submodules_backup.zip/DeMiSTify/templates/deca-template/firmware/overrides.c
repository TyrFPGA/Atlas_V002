/* Initial ROM */
// const char *bootrom_name="AUTOBOOTNES";
