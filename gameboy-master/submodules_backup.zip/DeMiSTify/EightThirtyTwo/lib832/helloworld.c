#include <stdio.h>

int main(int argc,char **argv)
{
	printf("Hello world! - %d\n",42);
	return(-1);
}

