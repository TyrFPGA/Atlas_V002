#ifndef CTYPE_H
#define CTYPE_H

int tolower(__reg("r1") int c);
int toupper(__reg("r1") int c);

#endif

