#ifndef STDBOOL_H
#define STDBOOL_H

typedef int bool;
#define true 1
#define false 0

#endif

