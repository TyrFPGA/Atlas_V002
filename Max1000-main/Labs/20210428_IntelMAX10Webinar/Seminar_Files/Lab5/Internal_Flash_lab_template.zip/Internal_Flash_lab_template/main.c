/*
 * main.c

 *-- MAX1000 NIOS II implementation
 *
 * (c) 2017 Arrow Central Europe GmbH
 *
 */

#include <stdio.h>
#include "system.h"
#include "altera_avalon_pio_regs.h"

int main()
{
	int count = 1;
	int delay;
	printf("Hello from Nios II!\n");

	while (1)
	{
		IOWR_ALTERA_AVALON_PIO_DATA(LEDS_BASE, count);
		for(delay=0; delay<65000; delay++);
		if(count<512)
		{
			count=count<<1;
		}
		else
		{
			count = 1;
		}
	}

	return 0;
}
