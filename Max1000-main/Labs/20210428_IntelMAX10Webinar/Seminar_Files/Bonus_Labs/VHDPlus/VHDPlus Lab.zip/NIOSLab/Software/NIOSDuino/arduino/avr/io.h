//! NIOSDuino custom file, (c) Dmitry Grigoryev, 2018

#ifndef _AVR_IO_H_
#define _AVR_IO_H_


#endif
