//! NIOSDuino custom file, (c) Dmitry Grigoryev, 2018

#ifndef _AVR_INTERRUPT_H_
#define _AVR_INTERRUPT_H_


#endif
