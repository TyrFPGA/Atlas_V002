/*=====================================
 * This example is a very simple memory test
 *======================================*/

#include <stdio.h>
#include <io.h>
#include "system.h"
#include "altera_avalon_pio_regs.h"

#define MEM_START 0x1FFF000
#define RANGE 0x0F

/*
* defines from Hello_World system.h
* #define NEW_SDRAM_CONTROLLER_0_BASE 0x1800000
* #define NEW_SDRAM_CONTROLLER_0_SPAN 8388608
* check that MEM_START is in the right range for your system
* avoid areas that Nios II may be using for code or data
*/

int main()
{
  int count, value;
  IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_BASE,0x00);  //0x07 LED3 on (0111)

  printf("Hello from Nios II!\n");

  //write a value to see change in debugger when single stepping
  IOWR(MEM_START,0, 0xdeadbeef);

  //write values to memory at MEM_START+value
  for (count=0; count<RANGE; count++)
  {
      IOWR(MEM_START, count, count);
  }

  //test values
  for (count=0; count<RANGE; count++)
    {
      value = IORD(MEM_START, count);
      if (value != count)
      {
          printf("Memory Error!\n");
          IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_BASE,0x01);  //0x07 LED3 on (0111)
      }
      else
      {
          if (count % 80 == 0) printf("\n");
          IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_BASE,count);  //0x07 LED3 on (0111)
         printf(".");
          }
    }

  printf("\n\n%i memory locations tested\nGoodbye from Nios II!\n", value);

  return 0;
}
