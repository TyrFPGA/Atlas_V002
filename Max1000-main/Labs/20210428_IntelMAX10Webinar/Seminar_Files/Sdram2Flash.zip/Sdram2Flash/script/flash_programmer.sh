#!/bin/sh
#
# This file was automatically generated.
#
# It can be overwritten by nios2-flash-programmer-generate or nios2-flash-programmer-gui.
#

#
# Converting ELF File: C:\MyFiles\Altera\Evalboards\Max1000\Designs\18.1\Lite\Sdram2Flash\software\flash1\flash1.elf to: "..\flash/flash1_flash_data.flash"
#
elf2flash --input="C:/MyFiles/Altera/Evalboards/Max1000/Designs/18.1/Lite/Sdram2Flash/software/flash1/flash1.elf" --output="../flash/flash1_flash_data.flash" --boot="$SOPC_KIT_NIOS2/components/altera_nios2/boot_loader_cfi.srec" --base=0x4080000 --end=0x40ce000 --reset=0x3000000 --verbose 

#
# Programming File: "..\flash/flash1_flash_data.flash" To Device: flash_data
#
nios2-flash-programmer "../flash/flash1_flash_data.flash" --base=0x4080000 --sidp=0x60 --id=0x0 --timestamp=1548858408 --device=1 --instance=0 '--cable=Arrow-USB-Blaster on localhost [USB0]' --program --verbose 

