/*
 * test_board
 *
 * main.c
 *
 */


#include "system.h"
#include "stdio.h"
#include "altera_avalon_pio_regs.h"
#include "altera_avalon_spi.h"

void init_g_sen();

int main()
{
	unsigned char wdata[1];
	unsigned char rdata[2];
	unsigned char led_out = 0x18;

	alt_8 y_value = 0;			// create buffer for filtering
	alt_8 y_value_1 = 0;
	alt_8 y_value_2 = 0;
	alt_8 y_value_3 = 0;
	alt_8 y_value_4 = 0;
	alt_8 y_value_5 = 0;

	alt_8 mode;
	alt_8 n_mode = 0x00;
	alt_u8 wb_send[1];
	alt_u8 wb_get[20];
	
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, 0x55); // reset mode counter
	
	//flash test - read jedec id and unique id
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, 0xFF);
	printf("\n============ WB_SPI_Flash Memory Test =============\n");
	printf("This software tests the Flash Memory in your system\n");
    printf("to assure it is working properly.\n");
	wb_send[0]=0x9f; // jedec id address
	alt_avalon_spi_command(SPI_FLASH_BASE, 0, 1, wb_send, 3, wb_get, 0);
	printf("\n	-> Read JEDEC ID: ");
	for (int i=0; i < 3; i++) {
		printf("%x", wb_get[i]);
	}
	printf("\n");

	wb_send[0]=0x4b; // unique id address
	alt_avalon_spi_command(SPI_FLASH_BASE, 0, 1, wb_send, 15, wb_get, 0);
	printf("	-> Read Unique ID: ");
	for (int i=4; i < 12; i++) {
		printf("%x", wb_get[i]);
	}
	printf("\n");

	init_g_sen();
	wdata[0]=0xC0 | 0x2A;		// read y-register and increment

	printf("\n\n================== LED sequences ==================\n");
	printf("Toggle between following LED sequences by pressing\n");
	printf("the user button:\n\n");
	printf("1. Spirit level\n");
	printf("2. Case statement sequence\n");
	printf("3. Shift register sequence\n");
	printf("4. Knightrider sequence\n");
	printf("5. Pulse-width modulation sequence\n");
	printf("\nCurrent LED sequence:\n");

	while (1)
	{
		mode = IORD_ALTERA_AVALON_PIO_DATA(PIO_MODE_BASE);

		if (mode != n_mode)
		{
			switch(mode)
			{
			case 0x01: printf("Mode = %d => Spirit level\n", mode); break;
			case 0x02: printf("Mode = %d => Case statement sequence\n", mode); break;
			case 0x03: printf("Mode = %d => Shift register sequence\n", mode); break;
			case 0x04: printf("Mode = %d => Knightrider sequence\n", mode); break;
			case 0x05: printf("Mode = %d => Pulse-width modulation sequence\n", mode); break;
			default: printf("Error: Select mode failed\n"); break;
			}
			n_mode = mode;
		}

		if(mode == 0x01)
		{
			// read y-axis data from g-sensor
			alt_avalon_spi_command (SPI_G_SENSOR_BASE, 0, 1, wdata, 2, rdata, 0);

			// calculate average
			y_value_5 = y_value_4;
			y_value_4 = y_value_3;
			y_value_3 = y_value_2;
			y_value_2 = y_value_1;
			y_value_1 = rdata[1];

			y_value = (y_value_1 + y_value_2 + y_value_3 + y_value_4 + y_value_5) / 5;

			// determine LED setting according to y-axis value
			if (y_value > -4 && y_value < 4)
				led_out = 0x18;
			if (y_value >= 4 && y_value < 8)
				led_out = 0x08;
			if (y_value >= 8 && y_value < 12)
				led_out = 0x04;
			if (y_value >= 12 && y_value < 16)
				led_out = 0x02;
			if (y_value >= 16)
				led_out = 0x01;
			if (y_value > -8 && y_value <= -4)
				led_out = 0x10;
			if (y_value > -12 && y_value <= -8)
				led_out = 0x20;
			if (y_value > -16 && y_value <= -12)
				led_out = 0x40;
			if (y_value <= -16)
				led_out = 0x80;

			// set LED
			IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, led_out);

			// wait 10 ms
			usleep(10000);
		}
	}
	return 0;
}

void init_g_sen()
{
	unsigned char wdata[3];
	unsigned char rdata[1];

	wdata[0]= 0x40 | 0x20;		// write multiple bytes with start address 0x20
	wdata[1]= 0x37;				// 25Hz mode, low power off, enable axis Z Y X
	wdata[2]= 0x00;				// all filters disabled

	alt_avalon_spi_command (SPI_G_SENSOR_BASE, 0, 3, wdata, 0, rdata, 0);

	wdata[0]= 0x40 | 0x22;		// write multiple bytes with start address 0x22
	wdata[1]= 0x00;				// all interrupts disabled
	wdata[2]= 0x00;				// continous update, little endian, 2g full scale, high resolution disabled, self test disabled, 4 wire SPI

	alt_avalon_spi_command (SPI_G_SENSOR_BASE, 0, 3, wdata, 0, rdata, 0);
}

