Project Description
==========================================================================
Important notes:
 1.Please do not use space character on path name.
 2.(Win OS)Please use short path name on Windows OS. This OS allows only 256 characters in normal path. 
 3.(Linux OS) Use bash as shell (change for example with: sudo dpkg-reconfigure dash)
 4.(Linux OS) Add access rights to bash files (change for example with: chmod 777 <filename>)
==========================================================================
1. Create Command Files and open documentation links:
  On Windows OS: run "_create_win_setup.cmd" and follow setup instructions 
  On Linux OS: run "_create_linux_setup.sh"  and follow setup instructions 
  Note: Created *.cmd/*.sh Files works only on project root directory. (It doesn't work to execute files on "<design root directory>/console/<type>/")
==============================
2. Create Quartus Project on Windows OS use instructions from option 1 of:
  1.Modify start setting:
  =====
  Edit "design_basic_settings.cmd" with text editor:
    Set your Quartus installation path for edit: 
      @set QUADIR=C:/intelFPGAlite
      @set QUARTUS_VERSION=18.1
      In this example the it search in 
        C:/intelFPGAlite/18.1 for quartus
        C:/intelFPGAlite/18.1/nios2eds for software
    Set the correct part number for your pcb variant (see board_files/TEIxxxx_devices.csv), edit:
      @set PARTNUMBER=<number from the csv list>
  =====
  2.Run "quartus_create_project_batchmode.cmd"
==============================
3. Create Quartus Project on Linux OS use instructions from option 1 of:
  1.Modify start setting:
  =====
  Edit "design_basic_settings.sh" with text editor:
    Set your Quartus installation path for edit: 
      @set QUADIR=~/intelFPGA_lite
      @set QUARTUS_VERSION=18.1
      In this example the it search in 
        ~/intelFPGA_lite/18.1 for quartus
        ~/intelFPGA_lite/18.1/nios2eds for software
    Set the correct part number for your pcb variant (see board_files/TEIxxxx_devices.csv), edit:
      @set PARTNUMBER=<number from the csv list>
  =====
  2.Run "quartus_create_project_batchmode.sh"
==============================
Basic documentations:
  =====
  Project Delivery - Intel devices:
  https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices 
  ==
  Trenz Electronic product description
  https://wiki.trenz-electronic.de/display/PD/Products
  ==
  Additional Information are available on the download page of the design
  https://wiki.trenz-electronic.de/display/PD/<Series Name>+Reference+Designs
==============================
=====
NOTES
=====