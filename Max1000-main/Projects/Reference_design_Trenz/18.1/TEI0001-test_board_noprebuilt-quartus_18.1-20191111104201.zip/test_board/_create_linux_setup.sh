# # --------------------------------------------------------------------
# # --   *****************************
# # --   *   Trenz Electronic GmbH   *
# # --   *   Holzweg 19A             *
# # --   *   32257 Bünde   	     *
# # --   *   Germany                 *
# # --   *****************************
# # --------------------------------------------------------------------
# # --$Autor: Dück, Thomas $
# # --$Email: t.dueck@trenz-electronic.de $
# # --$Create Date: 2019/11/07 $
# # --$Modify Date: 2019/11/07 $
# # --$Version: 1.0 $
# #    -- initial release 18.1
# # --------------------------------------------------------------------
# # --------------------------------------------------------------------
# init
function pause(){
   read -p "$*"
}

function te_base(){
echo "--------------------------------------------------------------------" 
echo "------------------------TE Reference Design-------------------------"
echo "--------------------------------------------------------------------"
echo "-- (c)  Go to CMD-File Generation (Manual setup)                    "
echo "-- (d)  Go to Documentation (Web Documentation)                     "
echo "-- (x)  Exit Batch (nothing is done!)                               "
echo "-- (0)  Module selection guide, project creation...                 "
echo "-- (1)  Create minimum setup of CMD-Files and exit Batch            "
echo "-- (2)  Create maximum setup of CMD-Files and exit Batch            "
echo "----                                                                "
echo " Select (ex.:'0' for module selection guide):"                                      
read new_base
if [ "${new_base}" == "d" ]; then te_doc ; fi
if [ "${new_base}" == "c" ]; then te_cmd ; fi
if [ "${new_base}" == "x" ]; then exit 1 ; fi
if [ "${new_base}" == "0" ]; then te_sel ; te_last; fi
if [ "${new_base}" == "1" ]; then te_min ; te_last; fi
if [ "${new_base}" == "2" ]; then te_max ; te_last; fi
te_base
}

function te_sel(){
  if ! [ -e "${bashfile_path}/design_basic_settings.sh" ]; then cp ${sh_folder}/design_basic_settings.sh ${bashfile_path}; fi
  if [ -e "${sh_folder}/quartus_create_project_bashmode.sh" ]; then cp ${sh_folder}/quartus_create_project_bashmode.sh ${bashfile_path}; fi
  if [ -e "${sh_folder}/quartus_open_existing_project_guimode.sh" ]; then cp ${sh_folder}/quartus_open_existing_project_guimode.sh ${bashfile_path}; fi

  # get paths
  bashfile_name=${0##*/}
  # bashfile_path=${0%/*}
  bashfile_path=`dirname $0`
  echo "-- Run Design with: ${bashfile_name}"
  echo "-- Use Design Path: ${bashfile_path}"
  echo "---------------------Load basic design settings---------------------"
  source ${sh_folder}/design_basic_settings.sh 
  DEF_QUARTUS_VERSION=${QUARTUS_VERSION}
  source $bashfile_path/design_basic_settings.sh
  echo "-- ${DEF_QUARTUS_VERSION} -- ${QUARTUS_VERSION}"
  if ! [ "${DEF_QUARTUS_VERSION}" == "${QUARTUS_VERSION}" ]; then  
    echo -----------------------------------------
    echo  "- Design was created for Quartus ${DEF_QUARTUS_VERSION}, selected is Quartus ${QUARTUS_VERSION}"
    echo  "- Design only tested with Quartus ${DEF_QUARTUS_VERSION}, modifications needed for other versions"
    echo "."
    echo "... Continue with ${QUARTUS_VERSION} ..."
  fi
  
  echo -----------------------------------------
  # check quartus installation
  while !  [ -e "${QUADIR}" ]
  do
    echo "'${QUADIR}' did not exists."
    echo "  Please specifiy your Quartus installation folder: "                                      
    read new_base
    export QUADIR=${new_base}
  done
   if  [ -e "${QUADIR}" ]; then
    echo "Use Quartus installation from '${QUADIR}'"
   fi
 
  echo "--------------------------------------------------------------------"
  # # --------------------
  echo "-- Use Quartus Version: ${QUARTUS_VERSION} --"
  echo "--------------------------------------------------------------------"
	echo "------------------- check old project exists -----------------------"
	quartus_p_folder=${bashfile_path}/quartus
	if !  [ -e "${QUADIR}" ]; then  
		echo "-- Error: ${QUADIR} not found. Check path of QUADIR variable on design_basic_settings.sh (upper and lower case is important)"
		echo "---------------------------Error occurs-----------------------------"
		echo "--------------------------------------------------------------------"
	else
		if [ -d "$quartus_p_folder" ]; then
			echo "Found old quartus project: Create project will delete old project!"
			echo "Are you sure to continue? (y/N):"
			read createProject
			if [ ${createProject} == y ] || [ ${createProject} == Y ]; then
				quartus_sel
			else
				echo "Create Quartus project is canceled."
			fi
		else
			quartus_sel
		fi
	fi
}  

function quartus_sel {
	echo "----------------------- Create log folder ---------------------------"
	# log folder
	log_folder=${bashfile_path}/log
	echo "${log_folder}"
	if [ -d "$log_folder" ]; then
		rm -rf ${log_folder}
	fi
	mkdir ${log_folder}   
	echo "--------------------------------------------------------------------"
	echo "-------------------------Start Quartus scripts -----------------------"
	${QUADIR}/${QUARTUS_VERSION}/nios2eds/nios2_command_shell.sh quartus_sh -t ${bashfile_path}/scripts/script_main.tcl --run_board_selection
	echo "-------------------------scripts finished----------------------------"
	echo "--------------------------------------------------------------------"
	echo "--------------------Change to design folder-------------------------"
	cd ..
	echo "------------------------Design finished-----------------------------"
	exit
}

function te_doc(){
echo "--------------------------------------------------------------------"
echo "-------------------------TE Documentation---------------------------"
echo "--------------------------------------------------------------------"
echo "-- (b)  Go to Base Menue"
echo "-- (x)  Exit Batch(nothing is done!)"

echo "-- (0)  Trenz Electronic Wiki"
echo "-- (1)  Trenz Electronic Wiki: Project Delivery - Intel devices"
echo "-- (1a) Trenz Electronic Wiki: Project Delivery-Quick Start"
echo "-- (1b) Trenz Electronic Wiki: Project Delivery-CMD Description"
echo "-- (2)  Trenz Electronic Downloads"
echo "----"                                                            
echo " Select Document (ex.:'0' for Wiki ,'b' go to Base Menue):"                                      
read new_doc
if [ "${new_doc}" == "b" ]; then te_base; fi
if [ "${new_doc}" == "x" ]; then exit 1; fi
if [ "${new_doc}" == "0" ]; then xdg-open https://wiki.trenz-electronic.de/display/PD/Trenz+Electronic+Documentation ; fi
if [ "${new_doc}" == "1" ]; then xdg-open https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices ; fi
if [ "${new_doc}" == "1a" ]; then xdg-open https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices#ProjectDelivery+Inteldevices-QuickStart ; fi
if [ "${new_doc}" == "1b" ]; then xdg-open https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices#ProjectDelivery+Inteldevices-LinuxCommandFiles ; fi
if [ "${new_doc}" == "2" ]; then xdg-open https://shop.trenz-electronic.de/en/Download/?path=Trenz_Electronic ; fi


te_doc
}     

function te_cmd(){
	echo "--------------------------------------------------------------------"
	echo "--------------------------Create CMD Files--------------------------"
	echo "--------------------------------------------------------------------"
	echo "-- Available CMD Files:                                             "
	echo "-- (b)  Go to Base Menue                                            "
	echo "-- (x)  Exit CMD Generation                                         "
	# echo "-- ( )  design_basic_settings.cmd (generated always, if not exist)"
	echo "-- (min)Generate minimum CMD setup                        (recommended)"
	echo "-- (max)Generate maximum CMD setup                        (not available)"
	echo "-- (1) quartus_create_project_bashmode.sh"
	echo "-- (2) quartus_open_existing_project_guimode.sh"
	echo "----     "
	echo " Select CMD Files (ex.:'min' for minimum setup, 'x' for exit):"                                      
	read new_cmd
	if [ "${new_cmd}" == "b" ]; then te_base; fi
	if [ "${new_cmd}" == "x" ]; then te_last; fi
	if [ "${new_cmd}" == "min" ]; then te_min; te_last; fi
	if [ "${new_cmd}" == "max" ]; then te_max; te_last; fi
	if [ "${new_cmd}" == "1" ]; then te_1; fi
	if [ "${new_cmd}" == "2" ]; then te_2; fi
	te_cmd                                                                
}
function te_min(){
	if [ -e "${sh_folder}/quartus_create_project_bashmode.sh" ]; then cp ${sh_folder}/quartus_create_project_bashmode.sh ${bashfile_path}; fi
	if [ -e "${sh_folder}/quartus_open_existing_project_guimode.sh" ]; then cp ${sh_folder}/quartus_open_existing_project_guimode.sh ${bashfile_path}; fi
	if ! [ -e "${bashfile_path}/design_basic_settings.sh" ]; then cp ${sh_folder}/design_basic_settings.sh ${bashfile_path}; fi
}                                                                   
   
function te_max(){
	if [ -e "${sh_folder}/quartus_create_project_bashmode.sh" ]; then cp ${sh_folder}/quartus_create_project_bashmode.sh ${bashfile_path}; fi
	if [ -e "${sh_folder}/quartus_open_existing_project_guimode.sh" ]; then cp ${sh_folder}/quartus_open_existing_project_guimode.sh ${bashfile_path}; fi
	if ! [ -e "${bashfile_path}/design_basic_settings.sh" ]; then cp ${sh_folder}/design_basic_settings.sh ${bashfile_path}; fi
}                                                                   
     
function te_1(){
	if [ -e "${sh_folder}/quartus_create_project_bashmode.sh" ]; then cp ${sh_folder}/quartus_create_project_bashmode.sh ${bashfile_path}; fi
}                                                                   
        
function te_2(){
if [ -e "${sh_folder}/quartus_open_existing_project_guimode.sh" ]; then cp ${sh_folder}/quartus_open_existing_project_guimode.sh ${bashfile_path}; fi
} 
                                                                  
   
function te_last(){
  if ! [ -e "${bashfile_path}/design_basic_settings.sh" ]; then cp ${sh_folder}/design_basic_settings.sh ${bashfile_path}; fi
  echo "---------------------------Minimal Setup----------------------------"
echo "--- 1. Open "design_basic_settings.sh" with text editor"
echo "--- 1.1  Set Quartus Installation path, default: QUADIR=<home directory>/intelFPGA_lite"
echo "--- 1.2  Set the Board Part you bought, example: PARTNUMBER=2"
echo "---       For available names see: ./board_files/TEIxxxx_devices.csv"
echo "--- 1.3 Save "design_basic_settings.sh""
echo "--- Create and open Quartus Project with batch files:"
echo "--- 2. To create quartus project, execute: ./quartus_create_project_bashmode.sh"
echo "--- Open existing Quartus Project with batch files:"
echo "--- 3. To open existing quartus project, execute: ./quartus_open_existing_project_guimode.sh"
echo "--- Use Trenz Electronic Wiki for more information:"
echo "---   https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices"
  echo "--------------------------------------------------------------------"
  pause 'Press [Enter] key to continue...'
  exit 1
}
   
echo "------------------------Set design paths----------------------------"
# get paths
bashfile_name=${0##*/}
bashfile_path=`dirname $0`
cd $bashfile_path

echo "-- Run Design with: $bashfile_name"
echo "-- Use Design Path: $bashfile_path"
sh_folder=${bashfile_path}/console/base_sh 
# run base menue
te_base
